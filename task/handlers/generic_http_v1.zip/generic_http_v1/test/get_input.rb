{
  'info' => {
    'enable_debug_logging' => 'true'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
    'method' => 'GET',
    'url' => 'https://www.google.com'
  }
}
